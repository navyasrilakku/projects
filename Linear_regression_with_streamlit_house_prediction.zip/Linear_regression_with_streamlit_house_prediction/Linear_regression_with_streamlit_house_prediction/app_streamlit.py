




import numpy as np
import pickle
import streamlit as st
from PIL import Image

# Load the model
pickle_in = open("house_model.pkl", "rb")
classifier = pickle.load(pickle_in)


def predict_price(MedInc, HouseAge, Population, AveOccup):
    prediction = classifier.predict([[MedInc, HouseAge, Population, AveOccup]])
    return prediction[0]


def main():
    st.set_page_config(page_title="Boston House Price Predictor", layout="centered")

    st.title("🏡 Boston House Price Predictor")

    st.markdown(
        """
        Welcome! This app uses a machine learning model to predict **house prices** in Boston 
        based on key features like Median Income, House Age, Population, and Average Occupancy.
        """
    )

    st.divider()

    # Input fields in columns for better layout
    col1, col2 = st.columns(2)
    with col1:
        MedInc = st.number_input("🧾 Median Income (in $1000s)", min_value=0.0, format="%.2f")
        HouseAge = st.number_input("🏘️ House Age (in years)", min_value=0.0, format="%.1f")
    with col2:
        Population = st.number_input("👥 Population", min_value=0.0, format="%.0f")
        AveOccup = st.number_input("🛏️ Average Occupancy", min_value=0.0, format="%.2f")

    st.divider()

    if st.button("🔍 Predict"):
        prediction = predict_price(MedInc, HouseAge, Population, AveOccup)
        st.success(f"💰 **Predicted House Price: ${prediction:,.2f}**")

    if st.button("ℹ️ About"):
        st.info("Developed using Streamlit | Dataset: Boston Housing\n\nModel: Trained on features like income, age, population, and occupancy.")

if __name__ == "__main__":
    main()
