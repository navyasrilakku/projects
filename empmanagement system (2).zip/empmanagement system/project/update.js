document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("updateemployee").addEventListener("submit", function (event) {
        event.preventDefault();

        const employeeData = {
            id: document.getElementById("id").value,
            name: document.getElementById("name").value,
            role: document.getElementById("role").value,
            dateOfJoining: document.getElementById("dateOfJoining").value,
            email: document.getElementById("email").value
        };

        fetch(`http://localhost:9090/employee/update/${employeeData.id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(employeeData)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.text(); // Read as text first
        })
        .then(text => {
            try {
                return text ? JSON.parse(text) : {}; // Parse JSON only if not empty
            } catch (error) {
                console.error("Invalid JSON response:", text);
                throw new Error("Failed to parse JSON response");
            }
        })
        .then(data => alert("Employee Updated Successfully!"))
        window.location.href = "index.html";
        .catch(error => console.error('Error:', error));
    });
});
