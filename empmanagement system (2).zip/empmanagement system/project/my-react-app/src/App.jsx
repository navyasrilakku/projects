import EmployeeManagement from "./components/EmployeeManagement";

function App() {
  return (
    <div>
      <EmployeeManagement />
    </div>
  );
}

export default App;
