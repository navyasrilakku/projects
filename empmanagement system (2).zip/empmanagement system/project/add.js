document.addEventListener("DOMContentLoaded", function () {
    const employeeForm = document.getElementById("employeeform");

    if (employeeForm) {
        employeeForm.addEventListener("submit", function (event) {
            event.preventDefault();

            const employeeData = {
                name: document.getElementById("empName").value,
                role: document.getElementById("empRole").value,
                dateOfJoining: document.getElementById("empDate").value,
                email: document.getElementById("empEmail").value
            };

            fetch("http://localhost:9090/employee/add", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(employeeData)
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error("Error adding employee");
                }
                return response.json();
            })
            .then(() => {
               alert("Employee added successfully!");
               // employeeForm.reset();
               window.location.href = "index.html";
            })
            .catch(error => console.error("Error:", error));
        });
    }
});
