document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("deleteemployee").addEventListener("submit", function (event) {
        event.preventDefault(); // Prevent form from refreshing the page
        
        const employeeId = document.getElementById("deleteId").value; // Get Employee ID
        
        if (!employeeId) {
            alert("Please enter a valid Employee ID!");
            return;
        }

        fetch(`http://localhost:9090/employee/delete/${employeeId}`, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json"
            }
        })
        .then(response => {
            if (response.status === 204) {
                return "Deleted"; // Custom success message for no content response
            } else if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json(); // If API returns JSON, process it
        })
        .then(data => {
            console.error("Error:", error);
            alert("Failed to delete employee. Please try again.");
        })
        .catch(error => {
            alert("Employee Deleted Successfully!");
            document.getElementById("deleteId").value = ""; // Clear input field
            window.location.href = "index.html";
        });
    });
});
