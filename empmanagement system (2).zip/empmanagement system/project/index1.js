import React, { useState, useEffect } from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";

const apiUrl = "http://localhost:9090/employee";

const EmployeeManagement = () => {
  const [employees, setEmployees] = useState([]);
  const [formData, setFormData] = useState({ id: "", name: "", email: "", role: "", dateOfJoining: "" });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    fetchEmployees();
  }, []);

  const fetchEmployees = async () => {
    try {
      const response = await axios.get(`${apiUrl}/all`);
      setEmployees(response.data);
    } catch (error) {
      alert("Error fetching employee data.");
    }
  };

  const validateEmployee = (employee) => {
    let newErrors = {};
    if (!/^[A-Za-z\s]{2,50}$/.test(employee.name)) newErrors.name = "Name must be 2-50 characters long and contain only letters";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(employee.email)) newErrors.email = "Invalid email address";
    if (!/^[A-Za-z\s]{2,30}$/.test(employee.role)) newErrors.role = "Role must be 2-30 characters long and contain only letters";
    if (new Date(employee.dateOfJoining) > new Date()) newErrors.dateOfJoining = "Joining date cannot be in the future";
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateEmployee(formData)) return;
    
    try {
      if (formData.id) {
        await axios.put(`${apiUrl}/update/${formData.id}`, formData);
        alert("Employee updated successfully!");
      } else {
        await axios.post(`${apiUrl}/add`, formData);
        alert("Employee added successfully!");
      }
      resetForm();
      fetchEmployees();
    } catch (error) {
      alert("Error saving employee data.");
    }
  };

  const editEmployee = (emp) => {
    setFormData(emp);
  };

  const deleteEmployee = async (id) => {
    if (window.confirm("Are you sure you want to delete this employee?")) {
      try {
        await axios.delete(`${apiUrl}/delete/${id}`);
        alert("Employee deleted successfully!");
        fetchEmployees();
      } catch (error) {
        alert("Error deleting employee.");
      }
    }
  };

  const resetForm = () => {
    setFormData({ id: "", name: "", email: "", role: "", dateOfJoining: "" });
    setErrors({});
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center text-white bg-dark p-3 rounded">Employee Management System</h2>
      <div className="card p-4 mt-3">
        <form onSubmit={handleSubmit}>
          <input type="hidden" name="id" value={formData.id} />
          <div className="mb-3">
            <input type="text" name="name" className="form-control" placeholder="Name" value={formData.name} onChange={handleChange} required />
            {errors.name && <div className="text-danger">{errors.name}</div>}
          </div>
          <div className="mb-3">
            <input type="email" name="email" className="form-control" placeholder="Email" value={formData.email} onChange={handleChange} required />
            {errors.email && <div className="text-danger">{errors.email}</div>}
          </div>
          <div className="mb-3">
            <input type="text" name="role" className="form-control" placeholder="Role" value={formData.role} onChange={handleChange} required />
            {errors.role && <div className="text-danger">{errors.role}</div>}
          </div>
          <div className="mb-3">
            <input type="date" name="dateOfJoining" className="form-control" value={formData.dateOfJoining} onChange={handleChange} required />
            {errors.dateOfJoining && <div className="text-danger">{errors.dateOfJoining}</div>}
          </div>
          <button type="submit" className="btn btn-success">Save Employee</button>
          <button type="button" className="btn btn-secondary ms-2" onClick={resetForm}>Cancel</button>
        </form>
      </div>
      <h3 className="text-center mt-4">Employee List</h3>
      <table className="table table-bordered mt-3 text-center">
        <thead className="thead-dark bg-secondary text-white">
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Joining Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {employees.map((emp) => (
            <tr key={emp.id}>
              <td>{emp.id}</td>
              <td>{emp.name}</td>
              <td>{emp.email}</td>
              <td>{emp.role}</td>
              <td>{new Date(emp.dateOfJoining).toLocaleDateString()}</td>
              <td>
                <button className="btn btn-warning btn-sm" onClick={() => editEmployee(emp)}>Edit</button>
                <button className="btn btn-danger btn-sm ms-2" onClick={() => deleteEmployee(emp.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default EmployeeManagement;
